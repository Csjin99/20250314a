package com.kh.mybatis.board.service;

import java.util.ArrayList;

import com.kh.mybatis.board.model.vo.Board;

public interface TestBoardService {
	ArrayList<Board> selectList();
}
